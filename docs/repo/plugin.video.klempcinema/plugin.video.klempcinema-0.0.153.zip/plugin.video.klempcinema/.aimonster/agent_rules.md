# Pravidla projektu — plugin_video_klempcinema

Agent načte tyto koleje při každém běhu AI Monster Engine / workspace agent.

## Identita
- **Slug:** `plugin_video_klempcinema`
- **Workspace:** `C:\Users\klemp\Desktop\programy\cinemakodek\plugin.video.klempcinema`
- **Typ:** odvozeno automaticky (doplň podle potřeby)

## Co se smí měnit
- Hlavní zdrojové soubory projektu (HTML/CSS u webu; Python u backendu)
- AI Monster markery a patche relevantní k úkolu

## Co se nesmí měnit
- `.aimonster/` interní soubory (kromě agent_rules na žádost)
- Server/bootstrap soubory při čistě vizuálních úpravách
- Mazání většiny obsahu souboru

## Design / konvence
- Zachovej existující barvy, fonty a layout tokens (`:root` / design system)
- Minimální diff — měň jen to, co úkol vyžaduje
- HTML/CSS: celý soubor v `content`, ne find+replace

## Poznámky
- Doplň barvy, sekce a kritické ID podle skutečného projektu.
- Globální pravidla: `.ai_monster/global/global_rules.md`
